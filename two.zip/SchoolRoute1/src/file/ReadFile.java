package file;
import java.io.*;

import java.util.Scanner;

import model.*;
public class ReadFile {
	public Vertex[] readVertexs(String filename) throws FileNotFoundException{
		Vertex[] vertexs;
		int count=0;
		File file = new File(filename);
		Scanner scanner = new Scanner(file);
		Scanner scanner2 = new Scanner(file);
		String []infos = new String[2];
		while(scanner.hasNextLine()){
			count++;
			scanner.nextLine();
		}
		vertexs = new Vertex[count];
		for(int i=0;scanner2.hasNextLine();i++){
			String info = scanner2.nextLine();
			infos = info.split(" ");
			//System.out.println(infos[0]);
			//System.out.println(infos[1]);
			vertexs[i] = new Vertex(infos[0], infos[1]);
			//vertexs[i].setId();
		
			//vertexs[i].setName();
		}
		scanner.close();
		scanner2.close();
		return vertexs;
	}
	public Egde[] readEgdes(String filename) throws FileNotFoundException{
		Egde[] egdes ;
		int count=0;
		File file = new File(filename);
		Scanner scanner = new Scanner(file);
		Scanner scanner2 = new Scanner(file);
		String []infos = new String[3];
		while (scanner.hasNextLine()) {
			count++;
			scanner.nextLine();
		}
		egdes = new Egde[count];
		for(int i=0;scanner2.hasNextLine();i++){
			String info = scanner2.nextLine();
			infos = info.split(" ");
			//System.out.println(infos[0]);
			//System.out.println(infos[1]);
			
			egdes[i] = new Egde(infos[0], infos[1],Integer.parseInt(infos[2]));//ת����int����
			//System.out.println(egdes[i].getSourceId()+" "+egdes[i].getDestinationId()+" "+egdes[i].getWeight() );
			//System.out.println(infos[2]);
			//vertexs[i].setId();
		
			//vertexs[i].setName();
		}
		scanner.close();
		scanner2.close();
		return egdes;
		
	}
	
	public String[] readRoute(String filename) throws FileNotFoundException{
		String[] routes;
		//int count=0;
		File file = new File(filename);
		Scanner scanner = new Scanner(file);
		Scanner scanner2 = new Scanner(file);
		int count=0;
		while(scanner.hasNext()){
			scanner.next();
			count++;
		}
		routes = new String[count];
		String info = scanner2.nextLine();
		routes = info.split(" ");
		
		scanner.close();
		scanner2.close();
		return routes;
	}
	
	public float[][] readTrans2D(String filename) throws FileNotFoundException{
		float[][] trans2D;
		String[] q;
		File j=new File(filename);
		Scanner pro=new Scanner(j);
		float a;
		String[] p;
		//int count=0;
		Scanner scanner1 = new Scanner(j);
		Scanner scanner2 = new Scanner(j);

		int i=0,n=0;

		while (scanner1.hasNextLine()) {
			i++;					
			scanner1.nextLine();	
		}
		String pro3=scanner2.nextLine();
		q=pro3.split(" ");
        n=q.length;
		trans2D =new float[i][n];

		for(int l=0;l<i;l++){//nextLine().split(" ")�����foreach��ֵ��Ч��
			p=pro.nextLine().split(" ");//Float.parseFloat������String������String[];			
			for(int k=0;k<n;k++){
				a=Float.parseFloat(p[k]);
		//		System.out.print(a+" ");
				trans2D[l][k]=a;
			}
			System.out.println();
		}
		pro.close();
        scanner1.close();
        scanner2.close();
		return trans2D;
		
	}
	
	
	
/*	public static void main(String args[]){
		ReadFile readFile = new ReadFile();
		//ReadFile readFile2 = new ReadFile();
		Vertex[] vertexs = new Vertex[40];
		Egde[] egdes = new Egde[300];
		String[] routes = new String[10];
		try {
			vertexs = readFile.readVertexs("../SchoolRoute1/place.txt");
			egdes = readFile.readEgdes("../SchoolRoute1/Edge.txt");
			routes = readFile.readRoute("../SchoolRoute1/route1.txt");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();//�Ҳ����ļ���ʱ�򷵻ض�Ӧ�Ĵ�����ʾ
		}
		for(Vertex vertex : vertexs){
			System.out.println(vertex.getId()+" "+vertex.getName());
		}
		System.out.println("place������");
		for(Egde egde:egdes){
			System.out.println(egde.getSourceId()+" "+egde.getDestinationId()+" "+egde.getWeight());
		}
		for(String s:routes){
			System.out.print(s+" ");
		}
		System.out.println();
	}*/
}
