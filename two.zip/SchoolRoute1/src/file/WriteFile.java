package file;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import model.*;
public class WriteFile {
	public void wirteVertex(Vertex[] vertexs) throws FileNotFoundException{
		File outputFile = new File("../SchoolRoute1/outputPlace.txt");
		PrintWriter wirter = new PrintWriter(outputFile);
		for(Vertex vertex:vertexs){
			wirter.println(vertex.getId()+" "+vertex.getName());
		}
		wirter.close();
	}
	public void wirteEdges(Egde[] egdes) throws FileNotFoundException{
		File outputFile = new File("../SchoolRoute1/outpuEdge.txt");
		PrintWriter wirter = new PrintWriter(outputFile);
		for(Egde egde:egdes){
		wirter.println(egde.getSourceId()+" "+egde.getDestinationId()+" "+egde.getWeight());
		}
		wirter.close();
	}
	public void writeRoutes(String[] routes) throws FileNotFoundException{
		File outputFile = new File("../SchoolRoute1/outputRoute1.txt");
		PrintWriter writer = new PrintWriter(outputFile);
		for(String s:routes){
			writer.print(s+" ");
		}
		writer.close();
	}
/*	public static void main(String args[]){
		ReadFile readFile = new ReadFile();
		WriteFile writeFile = new WriteFile();
		Vertex[] vertexs = new Vertex[40];
		Egde[] egdes = new Egde[300];
		String[] routes = new String[10];
		try {
			vertexs = readFile.readVertexs("../SchoolRoute1/place.txt");
			egdes = readFile.readEgdes("../SchoolRoute1/Edge.txt");
			routes = readFile.readRoute("../SchoolRoute1/route1.txt");
			writeFile.wirteVertex(vertexs);
			writeFile.wirteEdges(egdes);
			writeFile.writeRoutes(routes);
			System.out.println("����ɹ�");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}*/
}
