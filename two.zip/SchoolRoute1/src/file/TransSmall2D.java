package file;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import file.Dijkstra;

public class TransSmall2D {
	public float[][] transTosmall2D(int[] a) throws FileNotFoundException{
		File output = new File("../SchoolRoute1/small2D.txt");
		PrintWriter writer = new PrintWriter(output);
		float[][] distance ;//= new float[30][30];
	//	float[][] p;
		int n=a.length;
		float[][] small2D = new float[n][n];   //�洢С�ľ���
		int x=0;
		int y=0;
		Dijkstra distj = new Dijkstra();
		distance = distj.dist();//��ʼ������ȫ�Ѻ�������鸴�ƹ�ȥ��
		for(int i:a){
			for(int j:a){
				//System.out.println(distance[i][j]);
				small2D[x][y]=distance[i][j];
				//System.out.println(x+" "+y);
				if(y<n) y++;
			}
			if(x<n) {
				x++;
				y=0;
			}
		}
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				writer.print(small2D[i][j]+" ");
				System.out.print(small2D[i][j]+" ");
			}
			writer.println();
			System.out.println();
		}
		writer.close();
		return small2D;
	}
	
	/*public static void main(String args[]){
		int[] a={2,6,7,11,15};
		TransSmall2D t = new TransSmall2D();
		try {
			t.transTosmall2D(a);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
		
}
	
	

