package file;

import java.io.*;
//import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import model.Egde;


public class Trans2D {
	public int[][] trans2d(){
		Egde[] egdes = new Egde[300];
		ReadFile readFile = new ReadFile();
		File output = new File("../SchoolRoute1/2Dedges.txt");
		Map<String,Integer> map = new HashMap<String,Integer>();
		map.put("A", 1);
		map.put("B", 2);
		map.put("C", 3);
		map.put("D", 4);
		map.put("E", 5);
		map.put("F", 6);
		map.put("G", 7);
		map.put("H", 8);
		map.put("I", 9);
		map.put("J", 10);
		map.put("K", 11);
		map.put("L", 12);
		map.put("M", 13);
		map.put("N", 14);
		map.put("O", 15);
		map.put("P", 16);
		map.put("Q", 17);
		map.put("R", 18);
		map.put("S", 19);
		map.put("T", 20);
		map.put("U", 21);
		map.put("V", 22);
		map.put("W", 23);
		
		
		int[][] distance = new int[24][24];
		for(int i=1;i<distance.length;i++){
			for(int j=1;j<distance.length;j++){
				distance[i][j]=Integer.MAX_VALUE;
			}
		}
		try {
			PrintWriter writer = new PrintWriter(output);
			egdes = readFile.readEgdes("../SchoolRoute1/Edge.txt");
			for(Egde egde:egdes){
				int x=map.get(egde.getSourceId());
				int y=map.get(egde.getDestinationId());
				distance[x][y]=egde.getWeight();
				distance[y][x]=egde.getWeight();
			}
			for(int i=1;i<24;i++){
				for(int j=1;j<24;j++){
					writer.print(distance[i][j]+" ");
				}
				writer.println();
			}
			writer.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
		return distance;
	}
/*	public static void main(String[] args){
		Trans2D trans2d = new Trans2D();
		trans2d.trans2d();
	}*/
}
