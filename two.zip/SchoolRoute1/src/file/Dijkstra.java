package file;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import file.Trans2D;

public class Dijkstra {
	public void dijkstra(int v,int[][] a,int[] dist,int[] prev){
		int n=dist.length-1;
		if(v<1 || v>n) return;
		boolean[] s = new boolean[n+1];
		for(int i=1;i<=n;i++){
			dist[i]=a[v][i];
			s[i]=false;
			if(dist[i]==Integer.MAX_VALUE ) prev[i]=0;
			else prev[i]=v;
		}
		dist[v]=0;
		s[v]=true;
		for(int i=1;i<n;i++){
			float temp=Integer.MAX_VALUE;
			int u=v;
			for(int j=1;j<=n;j++){
				if(!s[j]&&dist[j]<temp){
					u=j;              
					temp=dist[j];
				}
			}
			s[u]=true;
			for(int j=1;j<=n;j++){
				if(!s[j]&&(a[u][j]<Integer.MAX_VALUE)){
					int newdist=dist[u]+a[u][j];
					if(newdist<dist[j]){
						dist[j]=newdist;
						prev[j]=u;
					}
				}
			}
		}
	}
	public float[][] dist() throws FileNotFoundException{
		File output = new File("../SchoolRoute1/shotrRoute.txt");
		PrintWriter writer = new PrintWriter(output);
		Trans2D trans2d = new Trans2D();
	//	int a[][]=null;
	//	a=trans2d.trans2d();
		float b[][]=new float[24][24];
		int j = 0;
		int a[][]=trans2d.trans2d();
		int[] dist = new int[a.length];
		int[] prev = new int[a.length];
		Dijkstra dijkstra = new Dijkstra();
		for(int i=0;i<a.length;i++){
			dijkstra.dijkstra(i+1, a, dist, prev);
			for(int d=1;d<dist.length;d++){//ע�⣬�����dist�����Ǵ�һ��ʼ�ģ�����������İ��ţ�����dist0��Ϊ0��
				b[i][j]= dist[d] ;
				j++;
				System.out.print(dist[d]);
				writer.print(dist[d]+" ");
			}
			j=0;
			System.out.println();
			writer.println();
		}
		writer.close();
		return b ;
	}

/*	public static void main(String[] args) throws FileNotFoundException{
		Dijkstra bb=new Dijkstra();
		bb.dist();
	} */
	
}
