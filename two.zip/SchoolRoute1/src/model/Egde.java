package model;

public class Egde {
	private String id;
	private Vertex source;
	private Vertex destination;
	private int weight;
	private String sourceId;
	private String destinationId;
	
	public Egde(String id,Vertex source,Vertex destination,int weight) {
		// TODO Auto-generated constructor stub
		this.id=id;
		this.source=source;
		this.destination=destination;
		this.weight=weight;
	}
	public Egde(String soruceId,String destinationId,int weight) {
		// TODO Auto-generated constructor stub
		this.sourceId=soruceId;
		this.destinationId=destinationId;
		this.weight=weight;
	}

	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Vertex getSource() {
		return source;
	}

	public void setSource(Vertex source) {
		this.source = source;
	}

	public Vertex getDestination() {
		return destination;
	}

	public void setDestination(Vertex destination) {
		this.destination = destination;
	}
	

	public String getSourceId() {
		return sourceId;
	}

	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}

	public String getDestinationId() {
		return destinationId;
	}

	public void setDestinationId(String destinationId) {
		this.destinationId = destinationId;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return source+" "+destination;
	}
}
