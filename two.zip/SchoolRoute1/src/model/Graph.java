package model;

import java.util.List;

public class Graph {
	private List<Vertex> vertexs;
	private List<Egde> egdes;
	
	public Graph(List<Vertex> vertexs,List<Egde> egdes) {
		// TODO Auto-generated constructor stub
		this.vertexs=vertexs;
		this.egdes=egdes;
	}

	public List<Vertex> getVertexs() {
		return vertexs;
	}

	public void setVertexs(List<Vertex> vertexs) {
		this.vertexs = vertexs;
	}

	public List<Egde> getEgdes() {
		return egdes;
	}

	public void setEgdes(List<Egde> egdes) {
		this.egdes = egdes;
	}
	
	
}
